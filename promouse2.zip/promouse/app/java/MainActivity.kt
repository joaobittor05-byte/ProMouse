class MainActivity : AppCompatActivity() {

    private var service: MouseService? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val view = View(this)
        setContentView(view)

        view.setOnTouchListener { _, event ->

            if (event.action == MotionEvent.ACTION_MOVE) {
                val dx = event.x - event.historySize
                val dy = event.y - event.historySize

                service?.onMouseMove(dx, dy)
            }

            true
        }
    }
}