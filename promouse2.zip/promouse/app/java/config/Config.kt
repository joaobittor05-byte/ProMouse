object Config {
    var sensX = 1.2f
    var sensY = 1.2f
    var acceleration = false
    var accelStrength = 0.04f
    var delayMs = 0L
    var liftKey = 62 // SPACE
}