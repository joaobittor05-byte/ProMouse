class MouseEngine {

    fun process(dx: Float, dy: Float): Pair<Float, Float> {

        var mx = dx * Config.sensX
        var my = dy * Config.sensY

        if (Config.acceleration) {
            val speed = kotlin.math.abs(dx) + kotlin.math.abs(dy)
            val factor = 1f + speed * Config.accelStrength
            mx *= factor
            my *= factor
        }

        return Pair(mx, my)
    }
}