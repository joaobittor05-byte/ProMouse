class TouchInjector(private val service: MouseService) {

    private val path = android.graphics.Path()

    fun inject(x: Float, y: Float) {

        path.reset()
        path.moveTo(x, y)

        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 1))
            .build()

        service.dispatchGesture(gesture, null, null)
    }
}