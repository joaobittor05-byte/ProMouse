class InputReader {

    val queue = java.util.concurrent.ConcurrentLinkedQueue<Pair<Float, Float>>()

    fun onMouseMove(dx: Float, dy: Float) {
        queue.offer(Pair(dx, dy))
    }

    fun poll(): Pair<Float, Float>? {
        return queue.poll()
    }
}