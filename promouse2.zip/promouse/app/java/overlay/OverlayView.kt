class OverlayView(context: Context) : View(context) {

    private val paint = Paint().apply {
        color = Color.RED
        strokeWidth = 5f
    }

    var xPos = 500f
    var yPos = 500f

    override fun onDraw(canvas: Canvas) {
        canvas.drawCircle(xPos, yPos, 10f, paint)
    }
}