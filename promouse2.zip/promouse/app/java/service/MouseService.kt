class MouseService : AccessibilityService() {

    private val engine = MouseEngine()
    private val input = InputReader()
    private lateinit var injector: TouchInjector

    private var liftPressed = false
    private var posX = 500f
    private var posY = 500f

    override fun onServiceConnected() {
        injector = TouchInjector(this)
        startLoop()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    private fun startLoop() {
        Thread {
            android.os.Process.setThreadPriority(
                android.os.Process.THREAD_PRIORITY_URGENT_DISPLAY
            )

            while (true) {
                val data = input.poll() ?: continue

                if (liftPressed) continue

                val (dx, dy) = data
                val (mx, my) = engine.process(dx, dy)

                posX += mx
                posY += my

                if (Config.delayMs > 0) {
                    Handler(Looper.getMainLooper()).postDelayed({
                        injector.inject(posX, posY)
                    }, Config.delayMs)
                } else {
                    injector.inject(posX, posY)
                }
            }
        }.start()
    }

    fun onKeyEvent(keyCode: Int, down: Boolean) {
        if (keyCode == Config.liftKey) {
            liftPressed = down
        }
    }

    fun onMouseMove(dx: Float, dy: Float) {
        input.onMouseMove(dx, dy)
    }
}